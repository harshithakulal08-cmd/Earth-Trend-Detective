import {humanCopy} from './human-impact-copy.mjs';
const keys=['partial','coverage','compare','search','close','baseline','change','year','meaning','cell','period','missing','regional','regionalScore','regionalFlood','nativeCell','noClimate','humid'];
const rows={
 en:['Some data available','{n}/6 estimates available. A score needs all six.','Compare places','Choose another place','Close comparison','2026 estimate','Change since 2026','Year','Indicator','Rare-flood depth estimate near the city centre.','Climate estimates use multi-year averages, not yearly weather forecasts.','No estimate for this indicator.','Regional estimate · 0.5° area, about 55 km north–south','Uses regional estimates','Average rare-flood depth across the surrounding region.','Estimate near the city centre','No climate data here. Country population is shown below.','Higher = wetter. Lower = drier.'],
 fr:['Quelques données disponibles','{n}/6 estimations disponibles. Le score exige les six.','Comparer des lieux','Choisir un autre lieu','Fermer la comparaison','Estimation 2026','Changement depuis 2026','Année','Indicateur','Profondeur estimée d’une crue rare près du centre-ville.','Le climat utilise des moyennes sur plusieurs années, pas des prévisions météo annuelles.','Pas d’estimation pour cet indicateur.','Estimation régionale · zone de 0,5°, environ 55 km nord–sud','Utilise des estimations régionales','Profondeur moyenne d’une crue rare dans la région autour du lieu.','Estimation près du centre-ville','Pas de données climatiques ici. La population du pays figure ci-dessous.','Plus haut = plus humide. Plus bas = plus sec.'],
 es:['Hay algunos datos','{n}/6 estimaciones disponibles. La puntuación necesita las seis.','Comparar lugares','Elige otro lugar','Cerrar comparación','Estimación de 2026','Cambio desde 2026','Año','Indicador','Profundidad estimada de una inundación poco frecuente cerca del centro.','El clima usa medias de varios años, no pronósticos meteorológicos anuales.','No hay estimación para este indicador.','Estimación regional · zona de 0,5°, unos 55 km de norte a sur','Usa estimaciones regionales','Profundidad media de una inundación poco frecuente en la región circundante.','Estimación cerca del centro','Sin datos climáticos aquí. La población del país aparece abajo.','Más alto = más húmedo. Más bajo = más seco.'],
 it:['Alcuni dati disponibili','{n}/6 stime disponibili. Il punteggio richiede tutte e sei.','Confronta luoghi','Scegli un altro luogo','Chiudi confronto','Stima del 2026','Variazione dal 2026','Anno','Indicatore','Profondità stimata di una rara piena vicino al centro.','Il clima usa medie di più anni, non previsioni del tempo annuali.','Nessuna stima per questo indicatore.','Stima regionale · area di 0,5°, circa 55 km nord–sud','Usa stime regionali','Profondità media di una rara piena nella regione circostante.','Stima vicino al centro','Nessun dato climatico qui. La popolazione del paese è sotto.','Più alto = più umido. Più basso = più secco.'],
 vi:['Có một phần dữ liệu','Có {n}/6 ước tính. Điểm cần đủ cả sáu.','So sánh địa điểm','Chọn địa điểm khác','Đóng so sánh','Ước tính 2026','Thay đổi từ 2026','Năm','Chỉ số','Độ sâu ước tính của lũ hiếm gặp gần trung tâm thành phố.','Khí hậu dùng trung bình nhiều năm, không phải dự báo thời tiết từng năm.','Không có ước tính cho chỉ số này.','Ước tính khu vực · vùng 0,5°, khoảng 55 km bắc–nam','Dùng ước tính khu vực','Độ sâu trung bình của lũ hiếm gặp trong vùng xung quanh.','Ước tính gần trung tâm thành phố','Không có dữ liệu khí hậu ở đây. Dân số cả nước ở bên dưới.','Cao hơn = ẩm hơn. Thấp hơn = khô hơn.'],
 ja:['一部のデータあり','6項目中{n}項目あり。スコアには6項目すべてが必要です。','場所を比較','別の場所を選ぶ','比較を閉じる','2026年の推計','2026年からの変化','年','指標','まれな洪水を想定した市中心部付近の浸水深。','気候は複数年の平均です。各年の天気予報ではありません。','この指標の推計値なし。','地域推計 · 0.5°の範囲、南北約55 km','地域推計を使用','まれな洪水を想定した周辺地域の平均浸水深。','市中心部付近の推計','この場所の気候データなし。国の人口は下に表示します。','高いほど湿潤。低いほど乾燥。'],
 zh:['部分数据可用','6项估计中有{n}项。评分需要全部六项。','比较地点','选择其他地点','关闭比较','2026年估计','相较2026年的变化','年份','指标','模拟罕见洪水时市中心附近的水深。','气候使用多年平均值，并非每年的天气预报。','此指标无估计值。','区域估计 · 0.5°范围，南北约55公里','使用区域估计','模拟罕见洪水时周边区域的平均水深。','市中心附近的估计','此处无气候数据。全国人口显示在下方。','越高越湿润，越低越干燥。'],
 'zh-Hant':['部分資料可用','6項估計中有{n}項。評分需要全部六項。','比較地點','選擇其他地點','關閉比較','2026年估計','相較2026年的變化','年份','指標','模擬罕見洪水時市中心附近的水深。','氣候使用多年平均值，並非每年的天氣預報。','此指標無估計值。','區域估計 · 0.5°範圍，南北約55公里','使用區域估計','模擬罕見洪水時周邊區域的平均水深。','市中心附近的估計','此處無氣候資料。全國人口顯示在下方。','越高越濕潤，越低越乾燥。'],
};
const comparisonSearch={
 en:['Choose another city','Choose another country','No matching place'],
 fr:['Choisir une autre ville','Choisir un autre pays','Aucun lieu trouvé'],
 es:['Elige otra ciudad','Elige otro país','No se encontró ningún lugar'],
 it:['Scegli un’altra città','Scegli un altro paese','Nessun luogo trovato'],
 vi:['Chọn thành phố khác','Chọn quốc gia khác','Không tìm thấy địa điểm'],
 ja:['別の都市を選ぶ','別の国を選ぶ','該当する場所がありません'],
 zh:['选择其他城市','选择其他国家','未找到匹配地点'],
 'zh-Hant':['選擇其他城市','選擇其他國家','找不到符合的地點']
};
export function placeReadingCopy(locale){
 const c=humanCopy(locale);
 const [searchCity,searchCountry,emptyPlace]=comparisonSearch[locale]||comparisonSearch.en;
 return {...Object.fromEntries(keys.map((key,i)=>[key,(rows[locale]||rows.en)[i]])),searchCity,searchCountry,emptyPlace,humidity:c.names.secheresse,
  summary:['chaleur','secheresse','feux','mer','fleuves','stabilite'].map(filter=>c.definitions[filter])};
}
